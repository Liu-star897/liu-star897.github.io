$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$exe  = Join-Path $here 'PlantsVsZombies.exe'

function Show-Box($text) {
  Add-Type -AssemblyName System.Windows.Forms
  [void][System.Windows.Forms.MessageBox]::Show($text, '植物大战僵尸 - 中文显示检查', 'YesNo', 'Warning')
}

$acp = $null
try { $acp = (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Nls\CodePage' -ErrorAction Stop).ACP } catch {}

if ($env:PVZ_TEST -eq '1') {
  'ACP=' + $acp
  exit
}

if ($acp -and $acp -ne '936') {
  $txt = @"
检测到你这台机器的「非 Unicode 程序」代码页是 $acp，
也就是开着「Beta: 使用 Unicode UTF-8 提供全球语言支持」。

这个游戏是 2009 年的老程序，中文走 GBK，开着那个选项会全变成方块和符号。

两个办法，任选一个：

1) 不改系统：用 Locale Emulator 右键 PlantsVsZombies.exe
   → Locale Emulator →「中文(简体，中国)」

2) 一劳永逸：设置 → 时间和语言 → 语言和区域 →
   管理语言设置 → 更改系统区域设置 →
   取消勾选「Beta: 使用 Unicode UTF-8 提供全球语言支持」→ 重启

（如果你的系统本来就是中文 Windows、没手动开过这个开关，
  那多半不是这个原因，可以点「是」直接进游戏看看。）

点「是」仍然启动游戏，点「否」退出。
"@
  Add-Type -AssemblyName System.Windows.Forms
  $r = [System.Windows.Forms.MessageBox]::Show($txt, '植物大战僵尸 - 中文显示检查', 'YesNo', 'Warning')
  if ($r -ne 'Yes') { exit }
}

Start-Process -FilePath $exe -WorkingDirectory $here
